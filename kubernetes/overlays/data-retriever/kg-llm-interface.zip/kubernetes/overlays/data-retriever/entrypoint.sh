cd /scripts
mkdir /kg-llm-interface
unzip kg-llm-interface.zip -d /kg-llm-interface
cd /kg-llm-interface
make test
